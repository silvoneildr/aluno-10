angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('aluno10.alunos', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/alunos.html',
        controller: 'alunosCtrl'
      }
    }
  })

  .state('aluno10.escolas', {
    url: '/page2',
    views: {
      'side-menu21': {
        templateUrl: 'templates/escolas.html',
        controller: 'escolasCtrl'
      }
    }
  })

  .state('aluno10.disciplinas', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/disciplinas.html',
        controller: 'disciplinasCtrl'
      }
    }
  })

  .state('aluno10', {
    url: '/side-menu21',
    templateUrl: 'templates/aluno10.html',
    controller: 'aluno10Ctrl'
  })

$urlRouterProvider.otherwise('/side-menu21/page1')

  

});